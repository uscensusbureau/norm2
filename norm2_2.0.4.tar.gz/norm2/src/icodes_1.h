"dynalloc                                                                ",&
"matrix_methods                                                          ",&
"norm_engine                                                             ",&
"quick_sort                                                              ",&
"random_generator                                                        ",&
